# todo_list
A To Do List using react 

npm install to install all dependencies

npm run start to launch
